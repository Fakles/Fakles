
Policy will be updated according to development and for this

your projects will not be reported Unless it's stage 3-4

I mean you can do whatever you want like any source codes

This policy includes both laws and rules

policy providing a comprehensive framework for governance and ensuring a balance between freedom and order

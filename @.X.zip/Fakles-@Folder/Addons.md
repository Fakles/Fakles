
### These are 2D and 3D designs from us, put our names on your project for freedom with the code

Fakles = ( /@.X/Fakles@ )

@.X.Ay-Contents = 

[Fakles-Build](https://cdn.discordapp.com/attachments/1264927571011829822/1264938732461625365/Fakles-Build.zip?ex=669fb17f&is=669e5fff&hm=3d2535453498ff4d855292aefd6286031b3467ce1df509ad35b13c169f75d5ea&)

[Fakles-Change](https://cdn.discordapp.com/attachments/1264927571011829822/1264938732805689375/Fakles-Change.zip?ex=669fb17f&is=669e5fff&hm=f941c28b8cdcdf0b58f7ccca47f9c77e221300a8aac26af5c4e4bf38c599c65f&) 

[Fakles-Icon](https://cdn.discordapp.com/attachments/1264927571011829822/1264938733216464979/Fakles-Icon.zip?ex=669fb17f&is=669e5fff&hm=a4997ca45ccc51611251b4241e06f6475afa3dd7444f1f1ab1b93281be4ff899&) 

[Fakles-Image](https://cdn.discordapp.com/attachments/1264927571011829822/1264938733556469771/Fakles-Image.zip?ex=669fb17f&is=669e5fff&hm=3f2b64ac0b4dd5d9258907ed0006c181de3403b1149d3916db866ecca7e27215&)

[Fakles-Pro](https://cdn.discordapp.com/attachments/1264927571011829822/1264938733892010125/Fakles-Pro.zip?ex=669fb17f&is=669e5fff&hm=66208ea79cda59175bb9e4bbc7ad50d88eb20cb14f518bd5c5228b71a8dc1eae&) 

[Fakles-Scene](https://cdn.discordapp.com/attachments/1264927571011829822/1264938734231621702/Fakles-Scene.zip?ex=669fb17f&is=669e5fff&hm=a84a1b23bff800fdae6198246634546995d10060f14c3ffa6a93053d2eb9c2c0&) 

[Fakles-Song](https://cdn.discordapp.com/attachments/1264927571011829822/1264938734579879946/Fakles-Song.zip?ex=669fb17f&is=669e5fff&hm=67287f68a5624ec9d31f79d167459f707b71928ba82424454dda95fd3c424a75&) 

[Fakles-Sound](https://cdn.discordapp.com/attachments/1264927571011829822/1264938735003238410/Fakles-Sound.zip?ex=669fb17f&is=669e5fff&hm=e2fda713700809607a0b8640bc14aaba27b3217db0ab01857432ee6edc13885d&) 

@.X.My-Contents =

[Fakles-Car](https://cdn.discordapp.com/attachments/1264927571011829822/1264939278488702996/Fakles-Car.zip?ex=669fb201&is=669e6081&hm=3d4d2695a4a099881fb9da53b230d01d457895b56b5deb96bce62ede348b2534&) 

[Fakles-Chair](https://cdn.discordapp.com/attachments/1264927571011829822/1264939278811795627/Fakles-Chair.zip?ex=669fb201&is=669e6081&hm=0b2c23fd6c58828e1e5497585c6e73b6da13b465aa22a3cf9298d4c91be6be79&) 

[Fakles-Console](https://cdn.discordapp.com/attachments/1264927571011829822/1264939279138947146/Fakles-Console.zip?ex=669fb201&is=669e6081&hm=8d63e5771275fbe720ea8a6c1edd87774be7236f1aeed6d959ba866386eeabbe&) 

[Fakles-Control](https://cdn.discordapp.com/attachments/1264927571011829822/1264939279457718353/Fakles-Control.zip?ex=669fb201&is=669e6081&hm=ee1dca24649ea899269e48b56b077edc8e5cc1426629bd6eb7ddf55e194b3fda&) 

[Fakles-Cup](https://cdn.discordapp.com/attachments/1264927571011829822/1264939279809773578/Fakles-Cup.zip?ex=669fb201&is=669e6081&hm=a0f9b4e024a1ea24251a39b5969ceef205ae9c469db202e5c270edb49206085c&) 

[Fakles-Desktop](https://cdn.discordapp.com/attachments/1264927571011829822/1264939280397238322/Fakles-Desktop.zip?ex=669fb201&is=669e6081&hm=2f51786437842ffda343275cadb06d9028a72355e1f90da2c83018f839f2264e&) 

[Fakles-DevMap](https://cdn.discordapp.com/attachments/1264927571011829822/1264939280787177593/Fakles-DevMap.zip?ex=669fb201&is=669e6081&hm=c8410c0c0f1858a88bfe358a8cc4ebb1a2958498dc9f882b2a1e1c7d35018601&) 

[Fakles-Door](https://cdn.discordapp.com/attachments/1264927571011829822/1264939281097687081/Fakles-Door.zip?ex=669fb202&is=669e6082&hm=7743c0e5abcd7799adf5094f8fdf364736cdb215dbf0d2b6ecceecaf5d07e4ac&) 

[Fakles-Effects](https://cdn.discordapp.com/attachments/1264927571011829822/1264939281428906084/Fakles-Effects.zip?ex=669fb202&is=669e6082&hm=46b4ff6a7c708977ab2e6195790101c6b6e14193ee5492c580880304c76ea219&) 

[Fakles-Female](https://cdn.discordapp.com/attachments/1264927571011829822/1264939281760129054/Fakles-Female.zip?ex=669fb202&is=669e6082&hm=e785b2d6ccfd179193a64257c241592fc7c289a90bea5bccdabe9e06addcad02&) 

[Fakles-Fish](https://cdn.discordapp.com/attachments/1264927571011829822/1264939443899338844/Fakles-Fish.zip?ex=669fb228&is=669e60a8&hm=1695f8d4307f19f47fa0782e69acef05a1d62f9d14775e3df243f0a6307ac72b&) 

[Fakles-Food](https://cdn.discordapp.com/attachments/1264927571011829822/1264939444327419914/Fakles-Food.zip?ex=669fb228&is=669e60a8&hm=7e25cd1ca5c1ea35a319c27ef2932bff6e5844d07034508b5c16f7eca7c755e1&) 

[Fakles-Hammer](https://cdn.discordapp.com/attachments/1264927571011829822/1264939444998246480/Fakles-Hammer.zip?ex=669fb229&is=669e60a9&hm=14618ddd0d74c96e8623508e306d88bf1fc9822fbbc64567667739b0d90c2ba0&) 

[Fakles-Male](https://cdn.discordapp.com/attachments/1264927571011829822/1264939445417934969/Fakles-Male.zip?ex=669fb229&is=669e60a9&hm=625d2d3e8ad5a5f312923aa44c78693cbaedc4818629289f9b2eb512de63b2a1&) 

[Fakles-Mobile](https://cdn.discordapp.com/attachments/1264927571011829822/1264939445853880380/Fakles-Mobile.zip?ex=669fb229&is=669e60a9&hm=6d0a0f1044f0838d94e040b77ecd7aa4efed0412ef28c25265adadf6017f1863&) 

[Fakles-Monitor](https://cdn.discordapp.com/attachments/1264927571011829822/1264939446210662400/Fakles-Monitor.zip?ex=669fb229&is=669e60a9&hm=3f5239c0531f401dc08d035568c23450190e484c6d528daf4c20d4103be52b92&) 

[Fakles-Paper](https://cdn.discordapp.com/attachments/1264927571011829822/1264939446583951413/Fakles-Paper.zip?ex=669fb229&is=669e60a9&hm=7f2bddc248a93a73c57f88946d60fd733d838ff27eabd918363f6ee1a61411af&) 

[Fakles-Pistol](https://cdn.discordapp.com/attachments/1264927571011829822/1264939447015702559/Fakles-Pistol.zip?ex=669fb229&is=669e60a9&hm=6df77dbd203773238aee56de524f257cd45397830e061dfc8bf0ccd034026055&) 

[Fakles-Plants](https://cdn.discordapp.com/attachments/1264927571011829822/1264939447405903872/Fakles-Plants.zip?ex=669fb229&is=669e60a9&hm=f34aacf2480d18c5f79f248dbfcc5673016469b1456502b35dbce29dd16a6058&) 

[Fakles-Sword](https://cdn.discordapp.com/attachments/1264927571011829822/1264939447905161249/Fakles-Sword.zip?ex=669fb229&is=669e60a9&hm=d96db204a8203e44514a6f0a9a38722090966229c9a35c808130423ccff3fb44&) 

[Fakles-Table](https://cdn.discordapp.com/attachments/1264927571011829822/1264939565227966464/Fakles-Table.zip?ex=669fb245&is=669e60c5&hm=ecbf3726fede5226b51c027144cfbf0ce85a87ffe2ed4ad14248c138d57e3e4c&) 

[Fakles-Tablet](https://cdn.discordapp.com/attachments/1264927571011829822/1264939565781749820/Fakles-Tablet.zip?ex=669fb245&is=669e60c5&hm=118a2fb7f84614faa7ece3751ee7d9ef8d93caeef1cae2f7277ac80851d9a0b5&) 

[Fakles-Window](https://cdn.discordapp.com/attachments/1264927571011829822/1264939566092255263/Fakles-Window.zip?ex=669fb245&is=669e60c5&hm=c71d45e4f0b8eb0950d38703fdb5c638afc9c76f01f0ff84c40e06112e99ef78&)

@.X.Sy-Contents = For All

@.X-Contents = By Fakle-20X

Fakles can create your dreams of whatever type you are
Your free with exclusive licenses and rights between us 

You can join us and our goal is deeper than you can imagine
But this does not mean that there is no laws

You can create a side Sy, Do you want to work as it is or change folders to make your source
But it is important that Sy still exists, And if something happened to your project you can backup anyway

but don't remove licenses the Fakles Folders and Files inside @Media, if @.X as zip been edit or delete
We respect all the world no matter your type Realize your projects and dreams

And hey we are freedom but don't breaking it 
But can make your projects

so before you follow his readers :)
good Luck :3

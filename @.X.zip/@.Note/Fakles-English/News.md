# Updates

Name : Rebuild From SM and Sy to Fakle and Fakles
Data : Sy20.4, Sy20X, SM20.4, SM20.5, SM20X. Fakle-20.5, Fakle-20X

We make next gen ways be like concept to true
Base And Core its Source Code and Changes folder are like git, tags, developers, historys

aka you can upgrade, downgrade, and tags for work without installed agine
Just only the files are editing, make sure your works put Folder & File

And Fakle its new and better with mix Fakles
so you need copy and rework

# Patch Notes

- 2024/7/21 : There are some @.X.Ay and @.X.My needs to be improved for later
- 2024/7/22 : @.X.Ay and @.X.My are improved and ready to use as Fakle-20.5
